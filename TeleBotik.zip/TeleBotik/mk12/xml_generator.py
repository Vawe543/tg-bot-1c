import xml.etree.ElementTree as ET

def generate_xml(product):
    root = ET.Element("Product")
    ET.SubElement(root, "ID").text = str(product[0])
    ET.SubElement(root, "QRCode").text = product[1]
    ET.SubElement(root, "Name").text = product[2]
    ET.SubElement(root, "Description").text = product[3]

    tree = ET.ElementTree(root)
    filename = f"product_{product[0]}.xml"
    tree.write(filename, encoding="utf-8", xml_declaration=True)
    return filename