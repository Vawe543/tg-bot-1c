from aiogram import Bot

async def send_notification(bot: Bot, user_id: int, message: str):
    try:
        await bot.send_message(user_id, message)
    except Exception as e:
        print(f"Ошибка отправки уведомления для {user_id}: {e}")