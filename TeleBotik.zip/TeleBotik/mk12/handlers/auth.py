from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from mk12.database import register_user, authenticate_user
from mk12.config import SECRET_PASSWORD

router = Router()

class AuthState(StatesGroup):
    waiting_for_password = State()

@router.message(F.text == "/start")
async def cmd_start(message: Message, state: FSMContext):
    telegram_id = message.from_user.id
    name = message.from_user.full_name
    register_user(telegram_id, name)
    await message.answer("Здравствуйте! Пожалуйста, введите пароль для аутентификации.")
    await state.set_state(AuthState.waiting_for_password)

@router.message(AuthState.waiting_for_password)
async def process_password(message: Message, state: FSMContext):
    if message.text.strip() == SECRET_PASSWORD:
        telegram_id = message.from_user.id
        authenticate_user(telegram_id)
        await message.answer("Вы успешно авторизованы!")
        await message.answer("Пришлите фото с QR-кодом для поиска информации.")
        await state.clear()
    else:
        await message.answer("Неверный пароль. Попробуйте снова.")