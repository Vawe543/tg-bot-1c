import sqlite3

def init_db():
    with sqlite3.connect("bot.db") as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                telegram_id INTEGER UNIQUE,
                name TEXT,
                is_authenticated BOOLEAN DEFAULT FALSE
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY,
                qr_code TEXT UNIQUE,
                product_name TEXT,
                description TEXT
            )
        """)
        # Добавим тестовый продукт
        cur.execute("INSERT OR IGNORE INTO products (qr_code, product_name, description) VALUES (?, ?, ?)",
                    ("123456", "Тестовый товар", "Это тестовое описание"))
        conn.commit()

def get_user(telegram_id):
    with sqlite3.connect("bot.db") as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,))
        return cur.fetchone()

def authenticate_user(telegram_id):
    with sqlite3.connect("bot.db") as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET is_authenticated=TRUE WHERE telegram_id=?", (telegram_id,))
        conn.commit()

def register_user(telegram_id, name):
    with sqlite3.connect("bot.db") as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO users (telegram_id, name) VALUES (?, ?)", (telegram_id, name))
        conn.commit()

def find_product_by_qr(qr_data):
    with sqlite3.connect("bot.db") as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM products WHERE qr_code=?", (qr_data,))
        return cur.fetchone()