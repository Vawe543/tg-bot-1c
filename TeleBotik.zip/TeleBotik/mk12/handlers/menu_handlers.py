from aiogram import Router
from aiogram.types import Message

router = Router()

@router.message(lambda message: message.text == "Распознать QR-код")
async def choose_qr(message: Message):
    await message.answer("Пришлите фото с QR-кодом для распознавания.")

@router.message(lambda message: message.text == "Сформировать XML для 1С")
async def choose_xml(message: Message):
    await message.answer("Введите ID товара, для которого нужно сформировать XML.")

@router.message(lambda message: message.text == "Помощь")
async def choose_help(message: Message):
    await message.answer("Вот, что я могу:\n\n"
                         "Отправляйте фото с QR-кодом — я его распознаю и найду в базе.\n"
                         "По запросу могу сформировать XML-файл для 1С.\n"
                         "Всегда можно вернуться в главное меню — просто напишите /menu")