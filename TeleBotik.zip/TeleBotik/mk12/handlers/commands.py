from aiogram import Router
from aiogram.types import Message
from mk12.keyboards import get_main_menu

router = Router()

@router.message(lambda message: message.text.lower() in ["меню", "/menu", "главное меню"])
async def cmd_menu(message: Message):
    await message.answer("Выберите функцию:", reply_markup=get_main_menu())