import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
DB_NAME = "bot.db"
ADMIN_IDS = list(map(int, os.getenv("ADMIN_IDS", "").split(",")))
SECRET_PASSWORD = os.getenv("AUTH_PASSWORD", "12345")