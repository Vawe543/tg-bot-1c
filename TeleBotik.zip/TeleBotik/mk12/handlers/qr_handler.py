from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from PIL import Image
import io
import pyzbar.pyzbar as pyzbar
from mk12.database import find_product_by_qr, get_user
from mk12.xml_generator import generate_xml
from aiogram.types.input_file import FSInputFile

router = Router()

@router.message(F.photo)
async def handle_photo(message: Message):
    telegram_id = message.from_user.id
    user = get_user(telegram_id)

    if not user or not user[3]:  # Проверка аутентификации
        await message.reply("Вы не авторизованы.")
        return

    if not message.photo:
        await message.reply("Пожалуйста, отправьте корректное фото.")
        return

    photo = message.photo[-1]

    try:
        file = await message.bot.download_file(photo.file_id)
    except TelegramAPIError as e:
        await message.reply("Не удалось загрузить фото. Попробуйте снова.")
        return

    try:
        image = Image.open(io.BytesIO(file.read()))
    except Exception as e:
        await message.reply(f"Не удалось обработать изображение: {e}")
        return

    decoded_objects = pyzbar.decode(image)

    if not decoded_objects:
        await message.reply("QR-код не найден на изображении.")
        return

    qr_data = decoded_objects[0].data.decode("utf-8")
    product = find_product_by_qr(qr_data)

    if product:
        xml_file = generate_xml(product)
        await message.reply(f"Информация о товаре:\n"
                            f"QR-код: {product[1]}\n"
                            f"Название: {product[2]}\n"
                            f"Описание: {product[3]}")
        await message.reply_document(document=FSInputFile(xml_file))
    else:
        await message.reply("Товар с таким QR-кодом не найден.")