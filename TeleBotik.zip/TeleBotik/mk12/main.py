import asyncio
from aiogram import Bot, Dispatcher
from config import BOT_TOKEN
from handlers.auth import router as auth_router
from handlers.qr_handler import router as qr_router
from handlers.commands import router as cmd_router
from handlers.menu_handlers import router as menu_router

async def main():
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher()

    dp.include_routers(
        auth_router,
        qr_router,
        cmd_router,
        menu_router,
    )

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())